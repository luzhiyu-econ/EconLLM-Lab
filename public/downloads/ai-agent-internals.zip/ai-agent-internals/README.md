# AI Agent 的工作原理

本包包含作者确认的正文、四张流程图及一张官方界面图。

- `chapter.md`：本章正文，使用包内图片路径。
- `diagrams/`：Draw.io 可编辑源、网页 SVG 和 PNG。
- `images/`：真实界面图、原图与来源记录。

流程图采用宋体、白底、灰标题栏、细矩形框、虚线分组和带动作标签的箭头。
真实界面图版权归原权利人，来源及处理记录见 `images/sources.md` 与 `images/sources.json`。
